# Music Recommendation System

This project predicts if a user will replay a song based on listening history and song features.

## Project Structure
- `data/`: Contains the dataset.
- `notebook/`: Jupyter notebook with analysis and model.
- `src/`: Python script for training the model.
- `requirements.txt`: List of dependencies.

## Instructions
1. Install requirements: `pip install -r requirements.txt`
2. Run the notebook or script to train and test the model.
