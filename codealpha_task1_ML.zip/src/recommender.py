
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

# Load data
df = pd.read_csv("../data/synthetic_music_data.csv")

# Encode categorical features
label_encoders = {}
for col in ['user_id', 'song_id', 'genre']:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

# Features and target
X = df[['user_id', 'song_id', 'tempo', 'popularity', 'genre']]
y = df['repeated_play']

# Scale features
scaler = StandardScaler()
X[['tempo', 'popularity']] = scaler.fit_transform(X[['tempo', 'popularity']])

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save model and encoders
joblib.dump(model, "recommender_model.pkl")
joblib.dump(scaler, "scaler.pkl")
for col, le in label_encoders.items():
    joblib.dump(le, f"{col}_encoder.pkl")

# Evaluate model
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))
